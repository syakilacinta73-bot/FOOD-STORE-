
// DATA PENGGUNA AWAL
let users = JSON.parse(localStorage.getItem("users")) || [
    {
        name: "Administrator",
        username: "admin",
        password: "admin123",
        role: "Admin"
    },
    {
        name: "Pengguna Toko",
        username: "user",
        password: "user123",
        role: "Pengguna"
    }
];

// DATA MAKANAN
let foods = [
    { name: "Nasi Goreng", price: 15000, stock: 20 },
    { name: "Mie Ayam", price: 12000, stock: 15 },
    { name: "Bakso", price: 13000, stock: 25 },
    { name: "Ayam Geprek", price: 18000, stock: 10 },
    { name: "Es Teh", price: 5000, stock: 30 }
];

let currentUser = null;

function saveUsers() {
    localStorage.setItem("users", JSON.stringify(users));
}

// LOGIN
document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    let user = users.find(u =>
        u.username === username && u.password === password
    );

    if (user) {
        currentUser = user;

        document.getElementById("loginPage").classList.add("hidden");
        document.getElementById("mainPage").classList.remove("hidden");

        document.getElementById("welcomeUser").textContent =
            "Halo, " + user.name + " (" + user.role + ")";

        document.getElementById("adminArea").classList.toggle(
            "hidden", user.role !== "Admin"
        );

        document.getElementById("loginMessage").textContent = "";

        updateDashboard();
        displayFoods();
        displayUsers();
        showSection("dashboard");

    } else {
        document.getElementById("loginMessage").textContent =
            "Username atau password salah!";
    }
});

// LOGOUT
function logout() {
    currentUser = null;

    document.getElementById("mainPage").classList.add("hidden");
    document.getElementById("loginPage").classList.remove("hidden");

    document.getElementById("loginForm").reset();
}

// NAVIGASI
function showSection(id) {
    document.querySelectorAll("main section").forEach(section => {
        section.classList.add("hidden");
    });

    document.getElementById(id).classList.remove("hidden");
}

// DASHBOARD
function updateDashboard() {
    document.getElementById("totalMakanan").textContent = foods.length;
    document.getElementById("totalPengguna").textContent = users.length;
}

// DATA MAKANAN
function displayFoods() {
    let table = document.getElementById("foodTable");

    table.innerHTML = foods.map((food, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${food.name}</td>
            <td>Rp ${food.price.toLocaleString("id-ID")}</td>
            <td>${food.stock}</td>
        </tr>
    `).join("");
}

// TAMBAH PENGGUNA
document.getElementById("userForm").addEventListener("submit", function(e) {
    e.preventDefault();

    if (!currentUser || currentUser.role !== "Admin") return;

    let name = document.getElementById("newName").value.trim();
    let username = document.getElementById("newUsername").value.trim();
    let password = document.getElementById("newPassword").value;
    let role = document.getElementById("newRole").value;

    if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
        alert("Username sudah digunakan!");
        return;
    }

    users.push({ name, username, password, role });

    saveUsers();
    displayUsers();
    updateDashboard();

    this.reset();
    alert("Pengguna berhasil ditambahkan!");
});

// MENAMPILKAN PENGGUNA
function displayUsers() {
    let table = document.getElementById("userTable");

    table.innerHTML = users.map((user, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${escapeHTML(user.name)}</td>
            <td>${escapeHTML(user.username)}</td>
            <td>${escapeHTML(user.role)}</td>
            <td>
                ${currentUser && currentUser.role === "Admin"
                    ? `<button class="edit-btn" onclick="editUser(${index})">Edit</button>
                       <button class="delete-btn" onclick="deleteUser(${index})">Hapus</button>`
                    : "-"}
            </td>
        </tr>
    `).join("");
}

// MENCEGAH INPUT HTML DITAMPILKAN SEBAGAI KODE
function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// EDIT PENGGUNA
function editUser(index) {
    if (!currentUser || currentUser.role !== "Admin") return;

    let user = users[index];

    let newName = prompt("Masukkan nama baru:", user.name);
    if (newName === null || !newName.trim()) return;

    let newUsername = prompt("Masukkan username baru:", user.username);
    if (newUsername === null || !newUsername.trim()) return;

    newUsername = newUsername.trim();

    if (users.some((u, i) =>
        i !== index && u.username.toLowerCase() === newUsername.toLowerCase()
    )) {
        alert("Username sudah digunakan!");
        return;
    }

    user.name = newName.trim();
    user.username = newUsername;

    saveUsers();
    displayUsers();
    alert("Data pengguna berhasil diubah!");
}

// HAPUS PENGGUNA
function deleteUser(index) {
    if (!currentUser || currentUser.role !== "Admin") return;

    if (users[index].username === currentUser.username) {
        alert("Admin tidak bisa menghapus akun yang sedang digunakan!");
        return;
    }

    if (confirm("Yakin ingin menghapus pengguna ini?")) {
        users.splice(index, 1);

        saveUsers();
        displayUsers();
        updateDashboard();

        alert("Pengguna berhasil dihapus!");
    }
}

// SIMPAN DATA PERTAMA KALI
saveUsers();
